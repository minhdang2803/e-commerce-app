/// export 'file's path';
/// Dùng cái này để gom mấy file liên quan thành 1 packet,
/// lúc import chỉ cần import 1 lần duy nhất
/// import 'screens.dart';

export 'home_screen/home_screen.dart';
export 'splash_screen.dart';
export 'onboarding_screen/onboarding_screen.dart';
export 'login_screen/login_screen.dart';
export 'register_screen/register_screen.dart';
export 'reset_password/reset_password_screen.dart';
export 'home_screen/home_screen.dart';