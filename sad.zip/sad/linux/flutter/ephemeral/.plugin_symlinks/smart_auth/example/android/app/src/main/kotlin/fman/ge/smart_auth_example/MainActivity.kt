package fman.ge.smart_auth_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
