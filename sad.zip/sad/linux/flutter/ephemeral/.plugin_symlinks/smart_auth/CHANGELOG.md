## 1.0.6
- Improved docs


## 1.0.5
- Remove downcast of Activity => FlutterActivity


## 1.0.4
- Replaced dart.io with foundation.dart


## 1.0.3
- Fake support of all operating systems, because other packages is depended on this one


## 1.0.1
- Fixed Reinitializing listeners
- Fixed Typos


## 0.9.1
Initial Release

- Android Autofill
  - SMS Retriever [API](https://developers.google.com/identity/sms-retriever/overview?hl=en)
  - SMS User Consent [API](https://developers.google.com/identity/sms-retriever/user-consent/overview)
- Showing Hint Dialog
- Getting Saved Credential
- Saving Credential
- Deleting Credential